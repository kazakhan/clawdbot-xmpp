ClawdBot CLI Plugin Registration Fix

This zip file contains fixes for a bug in ClawdBot 2026.1.24-3 where plugin CLI commands
registered via api.registerCli() were not available for lazy-loaded subcommands.

Files Modified:
- dist/cli/program/register.subclis.js
- dist/cli/program/command-registry.js  
- dist/cli/program/build-program.js
- dist/cli/run-main.js
- dist/index.js
- dist/plugins/cli.js (no changes needed, included for reference)

Installation:
1. Navigate to your ClawdBot installation:
   cd /usr/local/lib/node_modules/clawdbot  # Linux/Mac
   cd "C:\Users\username\AppData\Roaming\npm\node_modules\clawdbot"  # Windows

2. Backup original files (optional but recommended):
   cp -r dist dist.backup

3. Extract this zip file:
   unzip -o clawdbot-cli-fix.zip

4. Verify installation:
   clawdbot xmpp --help  # Should show XMPP plugin commands

Problem Fixed:
Plugin CLI commands (e.g., `clawdbot xmpp`) were only registered when running
`clawdbot plugins ...` because registerPluginCliCommands() was only called
for the plugins subcommand. This fix ensures plugin CLI commands are registered
for all subcommand registration paths.

Tested with XMPP plugin v1.0.0
